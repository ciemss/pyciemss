PEtab [1] is a data format that provides a standardized way for specifying parameter estimation
problems in systems biology, and integrates with existing standards for model specification. The
scope of PEtab is the full specification of the parameter estimation problem in typical systems
biology applications, including experimental conditons, priors, observation model transformations,
and several other features. PEtab is designed to be an intuitive, modular, machine- and human-readable
and -writable format. Extensive documentation and several examples are available:
https://github.com/PEtab-dev/PEtab

[1] Schmiester, L., Schälte, Y., Bergmann, F.T., Camba, T., Dudkin, E., Egert, J., Fröhlich, F., Fuhrmann,
L., Hauber, A.L., Kemmer, S., Lakrisenko, P., Loos, C., Merkt, S., Müller, W., Pathirana, D., Raimúndez,
E., Refisch, L., Rosenblatt, M., Stapor, P.L., Städter, P., Wang, D., Wieland, F.-G., Banga, J.R., Timmer,
J., Villaverde, A.F., Sahle, S., Kreutz, C., Hasenauer, J., Weindl, D., 2021. PEtab—Interoperable specification
of parameter estimation problems in systems biology. PLOS Computational Biology 17, e1008646.
https://doi.org/10.1371/journal.pcbi.1008646